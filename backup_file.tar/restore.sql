--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE zivseker;
--
-- Name: zivseker; Type: DATABASE; Schema: -; Owner: zivseker
--

CREATE DATABASE zivseker WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE zivseker OWNER TO zivseker;

\connect zivseker

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: scrapper; Type: SCHEMA; Schema: -; Owner: zivseker
--

CREATE SCHEMA scrapper;


ALTER SCHEMA scrapper OWNER TO zivseker;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: scrapper; Owner: zivseker
--

CREATE TABLE scrapper.categories (
    id integer NOT NULL,
    name text
);


ALTER TABLE scrapper.categories OWNER TO zivseker;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: scrapper; Owner: zivseker
--

CREATE SEQUENCE scrapper.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE scrapper.categories_id_seq OWNER TO zivseker;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: scrapper; Owner: zivseker
--

ALTER SEQUENCE scrapper.categories_id_seq OWNED BY scrapper.categories.id;


--
-- Name: prices; Type: TABLE; Schema: scrapper; Owner: zivseker
--

CREATE TABLE scrapper.prices (
    id integer NOT NULL,
    product_id integer,
    site_id integer,
    "time" timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    price double precision
);


ALTER TABLE scrapper.prices OWNER TO zivseker;

--
-- Name: prices_id_seq; Type: SEQUENCE; Schema: scrapper; Owner: zivseker
--

CREATE SEQUENCE scrapper.prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE scrapper.prices_id_seq OWNER TO zivseker;

--
-- Name: prices_id_seq; Type: SEQUENCE OWNED BY; Schema: scrapper; Owner: zivseker
--

ALTER SEQUENCE scrapper.prices_id_seq OWNED BY scrapper.prices.id;


--
-- Name: products; Type: TABLE; Schema: scrapper; Owner: zivseker
--

CREATE TABLE scrapper.products (
    id integer NOT NULL,
    category_id integer,
    name text,
    "time" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE scrapper.products OWNER TO zivseker;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: scrapper; Owner: zivseker
--

CREATE SEQUENCE scrapper.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE scrapper.products_id_seq OWNER TO zivseker;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: scrapper; Owner: zivseker
--

ALTER SEQUENCE scrapper.products_id_seq OWNED BY scrapper.products.id;


--
-- Name: sites; Type: TABLE; Schema: scrapper; Owner: zivseker
--

CREATE TABLE scrapper.sites (
    id integer NOT NULL,
    category_id integer,
    name text,
    base_url text,
    data_page text,
    "time" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE scrapper.sites OWNER TO zivseker;

--
-- Name: sites_id_seq; Type: SEQUENCE; Schema: scrapper; Owner: zivseker
--

CREATE SEQUENCE scrapper.sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE scrapper.sites_id_seq OWNER TO zivseker;

--
-- Name: sites_id_seq; Type: SEQUENCE OWNED BY; Schema: scrapper; Owner: zivseker
--

ALTER SEQUENCE scrapper.sites_id_seq OWNED BY scrapper.sites.id;


--
-- Name: categories id; Type: DEFAULT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.categories ALTER COLUMN id SET DEFAULT nextval('scrapper.categories_id_seq'::regclass);


--
-- Name: prices id; Type: DEFAULT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.prices ALTER COLUMN id SET DEFAULT nextval('scrapper.prices_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.products ALTER COLUMN id SET DEFAULT nextval('scrapper.products_id_seq'::regclass);


--
-- Name: sites id; Type: DEFAULT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.sites ALTER COLUMN id SET DEFAULT nextval('scrapper.sites_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: scrapper; Owner: zivseker
--

COPY scrapper.categories (id, name) FROM stdin;
\.
COPY scrapper.categories (id, name) FROM '$$PATH$$/3608.dat';

--
-- Data for Name: prices; Type: TABLE DATA; Schema: scrapper; Owner: zivseker
--

COPY scrapper.prices (id, product_id, site_id, "time", price) FROM stdin;
\.
COPY scrapper.prices (id, product_id, site_id, "time", price) FROM '$$PATH$$/3614.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: scrapper; Owner: zivseker
--

COPY scrapper.products (id, category_id, name, "time") FROM stdin;
\.
COPY scrapper.products (id, category_id, name, "time") FROM '$$PATH$$/3612.dat';

--
-- Data for Name: sites; Type: TABLE DATA; Schema: scrapper; Owner: zivseker
--

COPY scrapper.sites (id, category_id, name, base_url, data_page, "time") FROM stdin;
\.
COPY scrapper.sites (id, category_id, name, base_url, data_page, "time") FROM '$$PATH$$/3610.dat';

--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: scrapper; Owner: zivseker
--

SELECT pg_catalog.setval('scrapper.categories_id_seq', 15, true);


--
-- Name: prices_id_seq; Type: SEQUENCE SET; Schema: scrapper; Owner: zivseker
--

SELECT pg_catalog.setval('scrapper.prices_id_seq', 122, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: scrapper; Owner: zivseker
--

SELECT pg_catalog.setval('scrapper.products_id_seq', 80, true);


--
-- Name: sites_id_seq; Type: SEQUENCE SET; Schema: scrapper; Owner: zivseker
--

SELECT pg_catalog.setval('scrapper.sites_id_seq', 30, true);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: prices prices_pkey; Type: CONSTRAINT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.prices
    ADD CONSTRAINT prices_pkey PRIMARY KEY (id);


--
-- Name: products products_name_key; Type: CONSTRAINT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.products
    ADD CONSTRAINT products_name_key UNIQUE (name);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: sites sites_data_page_key; Type: CONSTRAINT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.sites
    ADD CONSTRAINT sites_data_page_key UNIQUE (data_page);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: scrapper; Owner: zivseker
--

ALTER TABLE ONLY scrapper.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

